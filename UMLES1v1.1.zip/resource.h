//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by UMLES1.rc
//
#define IDD_DIALOG                      101
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_COMBO1                      1002
#define IDC_EDIT3                       1003
#define IDC_EDIT4                       1004
#define IDC_EDIT18                      1005
#define IDC_EDIT5                       1006
#define IDC_EDIT6                       1007
#define IDC_EDIT7                       1008
#define IDC_EDIT8                       1009
#define IDC_EDIT9                       1010
#define IDC_COMBO2                      1011
#define IDC_EDIT10                      1012
#define IDC_EDIT11                      1013
#define IDC_EDIT12                      1014
#define IDM_APPLY                       1015
#define IDC_EDIT13                      1016
#define IDC_EDIT14                      1017
#define IDC_EDIT15                      1020
#define IDC_EDIT19                      1021
#define IDC_EDIT16                      1022
#define IDC_EDIT17                      1023
#define IDC_COMBO3                      1024
#define IDC_COMBO4                      1025
#define IDC_EDIT20                      1026
#define IDC_EDIT21                      1027
#define IDC_EDIT22                      1032
#define IDC_EDIT23                      1033
#define IDM_STOP                        1029
#define IDM_EXIT                        1030
#define IDC_PROGRESS                    1031
#define IDC_PRMESS                      1034

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1036
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
